<?php


declare(strict_types=1);

require_once __DIR__ . '/BaseHandler.php';
require_once __DIR__ . '/DiscountSupport.php';

final class CryptoCancelInvoiceHandler extends BaseHandler
{
    public function handle(): void
    {
        $this->requireMethod('POST');

        $orderId = FaoximaInput::string($this->data, 'order_id');
        if ($orderId === '') {
            FaoximaResponse::badRequest('order_id is required');
        }

        $report = FaoximaDb::fetchOne(
            'SELECT id_order, payment_Status, Payment_Method, atlaspay_order_id FROM Payment_report
              WHERE id_order = :o AND id_user = :u AND (source = \'miniapp\' OR (Payment_Method = \'tonpay\' AND tonpay_gateway_mode = \'custom\') OR (Payment_Method = \'atlaspay\' AND atlaspay_gateway_mode = \'custom\')) LIMIT 1',
            [':o' => $orderId, ':u' => (string)$this->user['id']]
        );
        if ($report === null) {
            FaoximaResponse::notFound('Payment not found');
        }
        $method = trim((string)($report['Payment_Method'] ?? ''));
        $cancellable = ['arze digital offline', 'plisio', 'nowpayment', 'digitaltron', 'cart to cart', 'carttocart_pv', 'iranpay2', 'tonpay', 'cubepay', 'blupal', 'variza', 'abangateway', 'atlaspay'];
        if (!in_array($method, $cancellable, true)) {
            FaoximaResponse::fail(422, 'این فاکتور قابل لغو از این طریق نیست');
        }
        $status = (string)($report['payment_Status'] ?? '');

        if ($method === 'tonpay' && function_exists('tonpayCustomFetchReport')) {
            $customReport = tonpayCustomFetchReport($orderId);
            if ($customReport !== null) {
                $customResult = tonpayCustomCancel($orderId, (string)$this->user['id']);
                if (empty($customResult['ok'])) {
                    FaoximaResponse::fail(409, (string)($customResult['message'] ?? 'لغو فاکتور انجام نشد.'));
                }
                FaoximaResponse::ok([
                    'kind'    => 'cancelled',
                    'message' => '✅ فاکتور لغو شد',
                ]);
                return;
            }
        }


        if ($method === 'atlaspay' && function_exists('atlaspayCustomFetchReport')) {
            $customReport = atlaspayCustomFetchReport($orderId);
            if ($customReport !== null) {
                $customResult = atlaspayCustomCancel($orderId, (string)$this->user['id']);
                if (empty($customResult['ok'])) {
                    FaoximaResponse::fail(409, (string)($customResult['message'] ?? 'لغو فاکتور انجام نشد.'));
                }
                FaoximaResponse::ok([
                    'kind'    => 'cancelled',
                    'message' => '✅ فاکتور لغو شد',
                ]);
                return;
            }
        }

        if (in_array($status, ['cancelled', 'paid', 'reject'], true)) {
            FaoximaResponse::ok([
                'kind'    => 'already_finalized',
                'message' => 'این فاکتور قبلاً نهایی شده است',
                'status'  => $status,
            ]);
            return;
        }

        if (!in_array($status, ['Unpaid', 'AwaitingHash', 'expire'], true)) {
            FaoximaResponse::fail(409, 'این فاکتور در وضعیتی نیست که قابل لغو باشد (' . $status . ')');
        }

        MiniDiscount::releaseLastUnpaidDiscount((string)$this->user['id']);

        if ($method === 'atlaspay' && function_exists('atlaspayCancelOrder')) {
            $atlaspayOrderId = trim((string)($report['atlaspay_order_id'] ?? ''));
            if ($atlaspayOrderId !== '') {
                try {
                    atlaspayCancelOrder($atlaspayOrderId);
                } catch (Throwable $e) {
                    FaoximaLogger::exception($e, 'AtlasPay cancel-order call failed', [
                        'user'  => $this->user['id'],
                        'order' => $orderId,
                    ]);
                }
            }
        }

        try {
            $pdo = FaoximaDb::pdo();
            $stmt = $pdo->prepare(
                "UPDATE Payment_report
                    SET payment_Status = 'cancelled'
                  WHERE id_order = :o
                    AND id_user = :u
                    AND source = 'miniapp'
                    AND payment_Status IN ('Unpaid', 'AwaitingHash', 'expire')"
            );
            $stmt->bindValue(':o', $orderId, PDO::PARAM_STR);
            $stmt->bindValue(':u', (string)$this->user['id'], PDO::PARAM_STR);
            $stmt->execute();
        } catch (Throwable $e) {
            FaoximaLogger::exception($e, 'Crypto cancel-invoice update failed', [
                'user'  => $this->user['id'],
                'order' => $orderId,
            ]);
            FaoximaResponse::serverError('خطا در لغو فاکتور');
        }

        if (function_exists('rx_ck_release_for_order')) {
            rx_ck_release_for_order($orderId, 'cancelled', 'crypto_cancelled');
        }

        FaoximaLogger::debug('Crypto invoice cancelled by user', [
            'user'  => $this->user['id'],
            'order' => $orderId,
        ]);

        FaoximaResponse::ok([
            'kind'    => 'cancelled',
            'message' => '✅ فاکتور لغو شد',
        ]);
    }
}
