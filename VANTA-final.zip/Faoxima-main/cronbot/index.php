script runed!
